package com.nokriver.fixedstatusbar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private StatusBarOverlayView overlayView;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (overlayView != null) overlayView.invalidate();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        showOverlay();
        handler.post(tick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (overlayView == null) showOverlay();
        return START_STICKY;
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        overlayView = new StatusBarOverlayView(this);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int flags =
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                dp(32),
                type,
                flags,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        try {
            windowManager.addView(overlayView, params);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "overlay_status_bar")
                : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("가짜 상태바 실행 중")
                .setContentText("다른 앱 위에 고정 상태바를 표시합니다.")
                .setOngoing(true);

        if (Build.VERSION.SDK_INT >= 21) builder.setColor(Color.BLACK);
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "overlay_status_bar",
                    "Fixed Status Bar Overlay",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("가짜 상태바 오버레이 실행 알림");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
        }
        overlayView = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    public static class StatusBarOverlayView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private static final float S = 1f / 1.3f;

        public StatusBarOverlayView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            text.setColor(Color.WHITE);
            text.setFakeBoldText(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);

            float w = getWidth();
            float h = getHeight();
            float d = getResources().getDisplayMetrics().density;

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK);
            c.drawRect(0, 0, w, h, p);

            float right = w - 8f * d;

            drawBattery(c, right - (27f * d * S), h / 2f, d);
            right -= (27f * d * S + 14f * d);

            drawSignal(c, right - (18f * d * S), h / 2f, d);
            right -= (18f * d * S + 14f * d);

            drawLTE(c, right - (20f * d * S), h / 2f, d);
        }

        private void drawLTE(Canvas c, float x, float cy, float d) {
            text.setColor(Color.WHITE);
            text.setFakeBoldText(true);
            text.setTextSize(10.5f * d * S);
            c.drawText("LTE", x, cy - 1.2f * d * S, text);
            text.setTextSize(8f * d * S);
            c.drawText("↓↑", x + 2f * d * S, cy + 7f * d * S, text);
        }

        private void drawSignal(Canvas c, float x, float cy, float d) {
            p.setColor(Color.WHITE);
            p.setStyle(Paint.Style.FILL);
            float base = cy + 6f * d * S;
            float bw = 3f * d * S;
            float gap = 3f * d * S;
            for (int i = 0; i < 4; i++) {
                float bh = (4 + i * 4) * d * S;
                RectF r = new RectF(x + i * (bw + gap), base - bh, x + i * (bw + gap) + bw, base);
                c.drawRoundRect(r, 2f * d * S, 2f * d * S, p);
            }
        }

        private void drawBattery(Canvas c, float x, float cy, float d) {
            p.setColor(Color.WHITE);
            p.setStyle(Paint.Style.FILL);
            RectF r = new RectF(x, cy - 8.5f * d * S, x + 27f * d * S, cy + 8.5f * d * S);
            c.drawRoundRect(r, 8.5f * d * S, 8.5f * d * S, p);

            text.setColor(Color.rgb(85,85,85));
            text.setFakeBoldText(true);
            text.setTextSize(10f * d * S);
            String b = "71";
            float tw = text.measureText(b);
            c.drawText(b, x + (27f * d * S - tw) / 2f, cy + 3.3f * d * S, text);
            text.setColor(Color.WHITE);
        }
    }
}
