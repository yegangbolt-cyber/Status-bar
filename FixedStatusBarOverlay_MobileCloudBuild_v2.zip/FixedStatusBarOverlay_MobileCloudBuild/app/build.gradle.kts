plugins {
    id("com.android.application")
}

android {
    namespace = "com.nokriver.fixedstatusbar"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nokriver.fixedstatusbar"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
