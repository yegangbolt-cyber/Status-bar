package com.nokriver.fixedstatusbar;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.lang.reflect.Method;
import java.util.List;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private StatusBarOverlayView overlayView;
    private TelephonyManager telephonyManager;
    private SignalStrength lastSignalStrength;

    private String signalText = "신호 강도 확인 중";

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (overlayView != null) overlayView.invalidate();
            updateSignalText();
            updateNotification();
            handler.postDelayed(this, 3000);
        }
    };

    private final PhoneStateListener signalListener = new PhoneStateListener() {
        @Override
        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
            super.onSignalStrengthsChanged(signalStrength);
            lastSignalStrength = signalStrength;
            updateSignalText();
            updateNotification();
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        startSignalListener();
        showOverlay();
        handler.post(tick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (overlayView == null) showOverlay();
        startSignalListener();
        updateNotification();
        return START_STICKY;
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        overlayView = new StatusBarOverlayView(this);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int flags =
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                dp(32),
                type,
                flags,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        try {
            windowManager.addView(overlayView, params);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void startSignalListener() {
        if (telephonyManager != null) return;

        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            signalText = "신호 강도: 권한 필요";
            return;
        }

        try {
            telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (telephonyManager != null) {
                telephonyManager.listen(signalListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
            }
        } catch (Exception e) {
            signalText = "신호 강도: 확인 불가";
        }
    }

    private void updateSignalText() {
        if (lastSignalStrength == null) {
            if (Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                signalText = "신호 강도: 권한 필요";
            } else {
                signalText = "신호 강도 확인 중";
            }
            return;
        }

        int level = lastSignalStrength.getLevel();
        int dbm = getBestDbm(lastSignalStrength);

        if (dbm > -300 && dbm < 0) {
            signalText = "신호 강도: " + level + "/4 · " + dbm + " dBm";
        } else {
            signalText = "신호 강도: " + level + "/4";
        }
    }

    private int getBestDbm(SignalStrength signalStrength) {
        try {
            Method method = SignalStrength.class.getMethod("getCellSignalStrengths");
            Object result = method.invoke(signalStrength);

            if (result instanceof List) {
                List list = (List) result;
                int best = -999;

                for (Object item : list) {
                    try {
                        Method getDbm = item.getClass().getMethod("getDbm");
                        Object dbmObj = getDbm.invoke(item);
                        if (dbmObj instanceof Integer) {
                            int dbm = (Integer) dbmObj;
                            if (dbm < 0 && dbm > best) best = dbm;
                        }
                    } catch (Exception ignored) {}
                }

                return best;
            }
        } catch (Exception ignored) {}

        return -999;
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "signal_overlay_channel")
                : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_menu_upload)
                .setContentTitle("공용 상태바 픽서")
                .setContentText(signalText)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setAutoCancel(false);

        if (Build.VERSION.SDK_INT >= 21) {
            builder.setColor(Color.BLACK);
            builder.setPriority(Notification.PRIORITY_LOW);
        }

        // setSilent(boolean)은 일부 빌드 환경에서 컴파일 오류가 날 수 있어 사용하지 않습니다.
        // 알림 소리/진동은 NotificationChannel에서 끄고, 구버전은 setSound(null)로 처리합니다.
        if (Build.VERSION.SDK_INT < 26) {
            builder.setSound(null);
        }

        return builder.build();
    }

    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(1, buildNotification());
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "signal_overlay_channel",
                    "공용 상태바 픽서",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("실제 신호 강도를 표시하는 고정 알림");
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.setShowBadge(false);

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);

        if (telephonyManager != null) {
            try {
                telephonyManager.listen(signalListener, PhoneStateListener.LISTEN_NONE);
            } catch (Exception ignored) {}
        }
        telephonyManager = null;

        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
        }
        overlayView = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    public static class StatusBarOverlayView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

        private static final float S = 0.84f;

        public StatusBarOverlayView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            text.setFakeBoldText(true);
            text.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);

            float w = getWidth();
            float h = getHeight();
            float d = getResources().getDisplayMetrics().density;

            // 요청대로 항상 흰색 아이콘, 테두리/그림자 없음
            int iconColor = Color.WHITE;

            float rightPad = 13.5f * d;
            float centerY = h / 2f + 1.7f * d;
            // 신호 아이콘 묶음을 더 아래로
            float signalOffsetY = 2.8f * d;

            float batteryW = 31f * d * S;
            // 점 없이 기존 막대 4개만 유지
            float signalGroupW = (3.15f * d * S) * 4f + (1.85f * d * S) * 3f;
            float lteW = 17.5f * d * S;

            float batteryX = w - rightPad - batteryW;
            float signalX = batteryX - 3.8f * d - signalGroupW;
            float lteX = signalX - 3.2f * d - lteW;

            drawLTE(c, lteX, centerY, d, iconColor);
            drawSignal(c, signalX, centerY + signalOffsetY, d, iconColor);
            drawBattery(c, batteryX, centerY, d, getBatteryPercent(), iconColor);
        }

        private int getBatteryPercent() {
            try {
                BatteryManager bm = (BatteryManager) getContext().getSystemService(Context.BATTERY_SERVICE);
                if (bm != null) {
                    int value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                    if (value >= 0) return value;
                }
            } catch (Exception ignored) {}
            return 71;
        }

        private void drawLTE(Canvas c, float x, float cy, float d, int color) {
            text.setColor(color);
            text.setTextSize(10.7f * d * S);
            c.drawText("LTE", x, cy - 2.9f * d * S, text);

            text.setTextSize(7.6f * d * S);
            c.drawText("↓↑", x + 1.7f * d * S, cy + 5.2f * d * S, text);
        }

        private void drawSignal(Canvas c, float x, float cy, float d, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);

            float barsX = x;
            float base = cy + 5.9f * d * S;
            float bw = 3.15f * d * S;
            float gap = 1.85f * d * S;

            for (int i = 0; i < 4; i++) {
                float bh = (5.4f + i * 3.8f) * d * S;
                RectF r = new RectF(
                        barsX + i * (bw + gap),
                        base - bh,
                        barsX + i * (bw + gap) + bw,
                        base
                );
                c.drawRoundRect(r, 1.9f * d * S, 1.9f * d * S, p);
            }
        }

        private void drawBattery(Canvas c, float x, float cy, float d, int batteryPercent, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            RectF r = new RectF(
                    x,
                    cy - 9.7f * d * S,
                    x + 31f * d * S,
                    cy + 9.7f * d * S
            );
            c.drawRoundRect(r, 9.7f * d * S, 9.7f * d * S, p);

            text.setColor(Color.rgb(78, 78, 78));
            text.setTextSize(10.9f * d * S);
            String b = String.valueOf(Math.max(0, Math.min(100, batteryPercent)));
            float tw = text.measureText(b);
            c.drawText(b, x + (31f * d * S - tw) / 2f, cy + 3.55f * d * S, text);
        }
    }

}