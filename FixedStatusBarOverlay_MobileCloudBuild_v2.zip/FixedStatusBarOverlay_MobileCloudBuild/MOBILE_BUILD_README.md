# 모바일만으로 APK 만들기: GitHub Actions 방식

이 프로젝트는 Android Studio 없이 GitHub Actions에서 APK를 빌드하도록 `.github/workflows/build-apk.yml` 파일을 포함합니다.

## 방법

1. GitHub에서 새 저장소를 만듭니다.
2. 이 프로젝트 안의 모든 파일을 저장소에 올립니다.
3. 저장소의 `Actions` 탭으로 이동합니다.
4. `Build APK` 워크플로를 선택합니다.
5. `Run workflow`를 누릅니다.
6. 빌드가 끝나면 실행 결과 페이지 아래쪽의 `Artifacts`에서 `FixedStatusBarOverlay-debug-apk`를 다운로드합니다.
7. 압축을 풀면 `app-debug.apk`가 있습니다.
8. 휴대폰에 설치합니다.
9. 앱 실행 후 `다른 앱 위에 표시 권한`을 허용하고 `가짜 상태바 시작`을 누릅니다.

## 주의

- 이 방식은 휴대폰 브라우저만으로도 가능하지만, GitHub에 파일을 올리는 과정이 조금 번거로울 수 있습니다.
- APK는 디버그 빌드입니다. 직접 쓰는 용도로는 설치 가능합니다.
- 설치가 막히면 Android 설정에서 `출처를 알 수 없는 앱 설치`를 허용해야 합니다.
