package com.nokriver.fixedstatusbar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private StatusBarOverlayView overlayView;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (overlayView != null) overlayView.invalidate();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        showOverlay();
        handler.post(tick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (overlayView == null) showOverlay();
        return START_STICKY;
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        overlayView = new StatusBarOverlayView(this);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int flags =
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                dp(32),
                type,
                flags,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        try {
            windowManager.addView(overlayView, params);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "overlay_status_bar")
                : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("가짜 상태바 실행 중")
                .setContentText("다른 앱 위에 고정 상태바를 표시합니다.")
                .setOngoing(true);

        if (Build.VERSION.SDK_INT >= 21) builder.setColor(Color.BLACK);
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "overlay_status_bar",
                    "Fixed Status Bar Overlay",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("가짜 상태바 오버레이 실행 알림");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
        }
        overlayView = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    public static class StatusBarOverlayView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.KOREA);
        private final String[] days = {"일", "월", "화", "수", "목", "금", "토"};
        private static final float S = 1f / 1.3f;

        public StatusBarOverlayView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            text.setFakeBoldText(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);

            float w = getWidth();
            float h = getHeight();
            float d = getResources().getDisplayMetrics().density;

            boolean darkMode = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;

            int bgColor = darkMode ? Color.BLACK : Color.WHITE;
            int fgColor = darkMode ? Color.WHITE : Color.rgb(45, 45, 45);
            int batteryTextColor = bgColor;

            p.setStyle(Paint.Style.FILL);
            p.setColor(bgColor);
            c.drawRect(0, 0, w, h, p);

            float leftPad = 12f * d;
            float rightPad = 12f * d;
            float baseline = h * 0.69f;

            Date now = new Date();
            Calendar cal = Calendar.getInstance(Locale.KOREA);
            cal.setTime(now);
            String time = timeFormat.format(now);
            String date = cal.get(Calendar.DAY_OF_MONTH) + "일 (" + days[cal.get(Calendar.DAY_OF_WEEK) - 1] + ")";

            text.setColor(fgColor);
            text.setTextSize(12.1f * d);
            float x = leftPad;
            c.drawText(time, x, baseline, text);
            x += text.measureText(time) + 9f * d;
            c.drawText(date, x, baseline, text);

            float batteryW = 28f * d * S;
            float signalW = (3f * d * S) * 4f + (2.15f * d * S) * 3f + 5.3f * d * S;
            float lteW = 18f * d * S;
            float groupRight = w - rightPad;

            float batteryX = groupRight - batteryW;
            float signalX = batteryX - 5.0f * d - signalW;
            float lteX = signalX - 4.8f * d - lteW;

            drawLTE(c, lteX, h / 2f, d, fgColor);
            drawSignal(c, signalX, h / 2f, d, fgColor);
            drawBattery(c, batteryX, h / 2f, d, getBatteryPercent(), fgColor, batteryTextColor);
        }

        private int getBatteryPercent() {
            try {
                BatteryManager bm = (BatteryManager) getContext().getSystemService(Context.BATTERY_SERVICE);
                if (bm != null) {
                    int value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                    if (value >= 0) return value;
                }
            } catch (Exception ignored) {}
            return 71;
        }

        private void drawLTE(Canvas c, float x, float cy, float d, int color) {
            text.setColor(color);
            text.setTextSize(10.2f * d * S);
            c.drawText("LTE", x, cy - 1.6f * d * S, text);
            text.setTextSize(7.4f * d * S);
            c.drawText("↓↑", x + 1.8f * d * S, cy + 7.1f * d * S, text);
        }

        private void drawSignal(Canvas c, float x, float cy, float d, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);

            float dotR = 1.8f * d * S;
            c.drawCircle(x + dotR, cy + 4.4f * d * S, dotR, p);

            float barsX = x + 5.3f * d * S;
            float base = cy + 7.2f * d * S;
            float bw = 3f * d * S;
            float gap = 2.15f * d * S;
            for (int i = 0; i < 4; i++) {
                float bh = (4.8f + i * 4.0f) * d * S;
                RectF r = new RectF(barsX + i * (bw + gap), base - bh, barsX + i * (bw + gap) + bw, base);
                c.drawRoundRect(r, 2f * d * S, 2f * d * S, p);
            }
        }

        private void drawBattery(Canvas c, float x, float cy, float d, int batteryPercent, int fillColor, int valueColor) {
            p.setColor(fillColor);
            p.setStyle(Paint.Style.FILL);
            RectF r = new RectF(x, cy - 8.9f * d * S, x + 28f * d * S, cy + 8.9f * d * S);
            c.drawRoundRect(r, 8.9f * d * S, 8.9f * d * S, p);

            text.setColor(valueColor);
            text.setTextSize(10.2f * d * S);
            String b = String.valueOf(Math.max(0, Math.min(100, batteryPercent)));
            float tw = text.measureText(b);
            c.drawText(b, x + (28f * d * S - tw) / 2f, cy + 3.5f * d * S, text);
        }
    }
}
