package com.nokriver.fixedstatusbar;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNeededPermissions();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(245, 245, 245));

        TextView title = new TextView(this);
        title.setText("공용 상태바 픽서");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(18));
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        statusText = new TextView(this);
        statusText.setTextSize(15);
        statusText.setTextColor(Color.DKGRAY);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, 0, 0, dp(18));
        root.addView(statusText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        Button permissionBtn = button("1. 다른 앱 위에 표시 권한 열기");
        permissionBtn.setOnClickListener(v -> openOverlayPermission());
        root.addView(permissionBtn);

        Button startBtn = button("2. 오른쪽 상태바 아이콘 시작");
        startBtn.setOnClickListener(v -> startOverlay());
        root.addView(startBtn);

        Button stopBtn = button("3. 정지");
        stopBtn.setOnClickListener(v -> stopOverlay());
        root.addView(stopBtn);

        TextView desc = new TextView(this);
        desc.setText(
                "실행 중에는 오른쪽 가짜 상태바 아이콘이 표시됩니다.\n" +
                "알림은 하나만 유지되며, 실제 신호 강도를 표시합니다.\n\n" +
                "재부팅 후에도 자동 실행되도록 BOOT_COMPLETED를 사용합니다.\n" +
                "삼성 기기에서는 배터리 설정을 '제한 없음'으로 두는 것이 안정적입니다."
        );
        desc.setTextSize(14);
        desc.setTextColor(Color.GRAY);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, dp(18), 0, 0);
        root.addView(desc);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;

        ArrayList<String> list = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            list.add(Manifest.permission.READ_PHONE_STATE);
        }

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            list.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!list.isEmpty()) {
            requestPermissions(list.toArray(new String[0]), 10);
        }
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54)
        );
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private void refreshStatus() {
        boolean overlayOk = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean phoneOk = Build.VERSION.SDK_INT < 23 ||
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;

        statusText.setText(
                "오버레이 권한: " + (overlayOk ? "허용됨" : "필요함") +
                "\n신호 강도 권한: " + (phoneOk ? "허용됨" : "필요함")
        );
    }

    private void openOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    private void startOverlay() {
        requestNeededPermissions();

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            return;
        }

        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void stopOverlay() {
        stopService(new Intent(this, OverlayService.class));
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
