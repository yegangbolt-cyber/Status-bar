# FixedStatusBarOverlay

홈 화면이든 다른 앱을 열었든, 상단에 가짜 상태바를 계속 띄우는 Android 오버레이 앱 프로젝트입니다.

## APK 빌드 방법

1. Android Studio에서 이 폴더를 엽니다.
2. Gradle Sync를 기다립니다.
3. Build > Build APK(s)를 누릅니다.
4. 생성된 APK를 휴대폰에 설치합니다.

## 사용 방법

1. 앱 실행
2. `다른 앱 위에 표시 권한 열기` 선택
3. 설정에서 `Fixed Status Bar` 권한 허용
4. 앱으로 돌아와 `가짜 상태바 시작` 선택

## 한계

- 일반 APK 방식이므로 루팅 없이 가능한 `TYPE_APPLICATION_OVERLAY` 방식입니다.
- 일부 보안 화면, 권한 화면, 잠금화면, 결제 화면에서는 Android가 오버레이를 숨길 수 있습니다.
- 실제 시스템 상태바를 영구 교체하는 것이 아니라, 화면 최상단에 오버레이 View를 띄우는 방식입니다.
